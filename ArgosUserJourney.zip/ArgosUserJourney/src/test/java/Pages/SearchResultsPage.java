package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchResultsPage {


    public SearchResultsPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }



    @FindBy(xpath = "//a[contains(text(),'SIM Free Alcatel 1B 32GB Mobile Phone - Black')]")
    public WebElement alcatelMobilePhone;



}
