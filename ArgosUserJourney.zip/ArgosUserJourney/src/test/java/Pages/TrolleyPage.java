package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TrolleyPage {

    public TrolleyPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }

    @FindBy(xpath = "(//input[@id='basket-FulfilmentSelectorForm'])[2]")
    public WebElement checkPostCodeOrTownField;


    @FindBy(id = "quantity9437643")
    public WebElement productQuantityTrolleyScreen;

//    @FindBy(id = "basket-FulfilmentSelectorForm-collectButton")
//    public WebElement collectionBu

    @FindBy(xpath = "(//button[@id='basket-FulfilmentSelectorForm-collectButton'])[2]")
    public WebElement deliveryButton;

    @FindBy(xpath = "//span[contains(text(),'Pay and collect')]")
    public WebElement payAndCollectButton;

    //span[contains(text(),'Pay now and collect')]

    @FindBy(xpath = "(//button[contains(text(),'Select this store')])[1]")
    public WebElement findAStoreMCRFortStore;

    @FindBy(xpath = "//button[@data-e2e='continue-with-collection-button']")
    public WebElement payAndCollectTWO;


}
