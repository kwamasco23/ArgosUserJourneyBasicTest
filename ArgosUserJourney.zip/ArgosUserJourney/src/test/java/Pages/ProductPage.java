package Pages;

import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class ProductPage {



    public ProductPage()
    {
        //PageFactory.initElements(Driver.get(),this);
        PageFactory.initElements(Driver.get(),this);
    }



    @FindBy(id = "quantity8374556")
    public WebElement trolleyQuantity;


      public WebElement addTrolley(String trolleyLocator)
  {
String fullLocator = "(//a[contains(text(),'"+trolleyLocator+"')]/../../..//button)[2]";
return Driver.get().findElement(By.xpath(fullLocator));
  }


    @FindBy(xpath = "//a[contains(text(),'Continue without insurance')]")
    public WebElement continueWithoutInsurance;





}
