package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandingPage {


    //constructor

    public LandingPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }

    @FindBy(xpath = "//button[@id='consent_prompt_submit']")
    public WebElement cookiesBTN;


    @FindBy(xpath = "//input[@id='searchTerm']")
    public WebElement searchBox;

    @FindBy(xpath = "//button[@class='_2mKaC']")
    public WebElement searchButton;

    @FindBy(xpath = "//span[contains(text(),'Account')]")
    public WebElement accountLink;

    @FindBy(xpath = "//input[@name='emailAddress']")
    public WebElement emailField;

    @FindBy(xpath = "//input[@name='currentPassword']")
    public WebElement passwordField;

    @FindBy(xpath = "//button[contains(text(),'Sign in securely')]")
    public WebElement signInButton;






}
