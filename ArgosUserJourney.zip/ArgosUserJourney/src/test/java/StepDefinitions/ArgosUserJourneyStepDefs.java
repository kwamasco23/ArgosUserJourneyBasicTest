package StepDefinitions;

import Pages.LandingPage;
import Pages.ProductPage;
import Pages.SearchResultsPage;
import Pages.TrolleyPage;
import Utilities.Driver;
import Utilities.PropertiesReader;
import io.cucumber.java.en.*;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.concurrent.TimeUnit;


public class ArgosUserJourneyStepDefs {
LandingPage landingPage = new LandingPage();
SearchResultsPage searchResultsPage =new SearchResultsPage();
//ProductPage productScreen =new ProductPage();
    ProductPage productScreen =new ProductPage();
TrolleyPage trolleyPage =new TrolleyPage();

    @Given("User searches for product on landing page")
    public void user_searches_for_product_on_landing_page() throws InterruptedException {

        Driver.get().get(PropertiesReader.get("url"));
        Assert.assertTrue(Driver.get().getTitle().contains("Argos | Order online today for fast home delivery"));
        Thread.sleep(1000);
        landingPage.cookiesBTN.click();
        landingPage.searchBox.sendKeys("mobile");
        for (int i=0; i<1; i++)
        {
            landingPage.searchBox.sendKeys(Keys.ARROW_DOWN);
        }
        landingPage.searchBox.sendKeys(Keys.ENTER);
        landingPage.searchButton.click();
        Thread.sleep(1500);
    }


    @And("User selects {string} on search results screen")
    public void user_selects_on_search_results_screen(String productName) throws InterruptedException {
Assert.assertTrue(Driver.get().getTitle().contains("Results for mobile phone in Technology, Mobile phones"));
        JavascriptExecutor js = (JavascriptExecutor) Driver.get();
        js.executeScript("window.scrollBy(0,250)", productScreen.addTrolley(productName));
        productScreen.addTrolley(productName).click();
        Driver.get().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

    }


    @And("User selects continue without insurance option")
    public void user_selects_continue_without_insurance_option() {
        productScreen.continueWithoutInsurance.click();
        Driver.get().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    }

    @And("User selects trolley quantity")
    public void user_selects_trolley_quantity() throws InterruptedException {
        Select quantity =new Select(productScreen.trolleyQuantity);
        quantity.selectByValue("2");
        Assert.assertTrue(Driver.get().getTitle().contains("Trolley"));
       Driver.get().manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
    }

    @When("User selects delivery")
    public void user_selects_delivery() throws InterruptedException {
        trolleyPage.checkPostCodeOrTownField.sendKeys("m8 9dp");
        trolleyPage.deliveryButton.click();
        Thread.sleep(1000);
        trolleyPage.findAStoreMCRFortStore.click();
        trolleyPage.payAndCollectTWO.click();
    }

    @Then("User should be taken to Sign In screen")
    public void user_should_be_taken_to_sign_in_screen() {
        List<WebElement> list = Driver.get().findElements(By.xpath("//h1[contains(text(),'Sign in')]"));
        Assert.assertTrue("Text not found!", list.size() > 0);
        Assert.assertTrue(Driver.get().getTitle().contains("Login"));
        Driver.get().manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
    }

}
